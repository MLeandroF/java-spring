package br.com.estudos.entrega1;

public class TestaSoma {

	
	public static void main(String[] args) {	

		Soma soma = new Soma();
		
		soma.total = soma.numero1 + soma.numero2;
		System.out.println("A somatoria dos numeros e " + soma.total);
		
		
		
	}
}
