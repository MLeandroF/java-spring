package br.com.estudos.entrega1;

import java.util.Scanner;

public class Soma {
	
		int numero1;
		int numero2;
		int total;

	public Soma() {


		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("Digite o primeiro numero: ");
		numero1 = scanner.nextInt();
		System.out.println("Digite o segundo numero: ");
		numero2 = scanner.nextInt();
		
		total = numero1 + numero2;

		
	}
		

}